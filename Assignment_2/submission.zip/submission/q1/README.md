Kernel Trick for separating linearly inseparable data using Perceptron

Kernels used are:

1.	(X, Y, Z)=(x, y, x^2+y^2)
	Accuracy is 1.000 and the plots are:

2.	(X, Y, Z)=(x, y, x^4+y^2)
	Accuracy is 0.9750 and the plots are:

3.	(X, Y, Z)=(x, y, x^4+y^2)
	Accuracy is 0.9350 and the plots are:


English letter classification using Support Vector Machines
The kernels used were: 
1.	Linear 
2.	Polynomial 
3.	RBF

And the hyperparameters tested were C, Gamma, degree and coef0
C is the parameter for the soft margin cost function.
Gamma is the free parameter of the Gaussian radial basis function.

RBG implicitly maps every point to an infinite dimensional space and the parameters used here are C, Gamma , degree and coef0.

Variation with C:
The C parameter trades off misclassification of training examples against simplicity of the decision surface. A low C makes the decision surface smooth, while a high C aims at classifying all training examples correctly by giving the model freedom to select more samples as support vectors. So we have to choose C which is not too high or too low.

Variation with Gamma:

The behavior of the model is very sensitive to the gamma parameter. If gamma is too large, the radius of the area of influence of the support vectors only includes the support vector itself and no amount of regularization with C will be able to prevent overfitting.
When gamma is very small, the model is too constrained and cannot capture the complexity or “shape” of the data. The region of influence of any selected support vector would include the whole training set. The resulting model will behave similarly to a linear model with a set of hyperplanes that separate the centers of high density of any pair of two classes.So we have to choose Gamma which is not too high or too low.
